import paramiko
from azure.storage.blob import BlobServiceClient
from datetime import datetime
import os
import csv
import io

def copy_files_batch(payload: list):
    sftp_host = "sftp.headquarters.newcenturyhealth.com"
    sftp_port = 22
    sftp_user = "yourusername"
    sftp_pass = "yourpassword"

    transport = paramiko.Transport((sftp_host, sftp_port))
    transport.connect(username=sftp_user, password=sftp_pass)
    sftp = paramiko.SFTPClient.from_transport(transport)

    blob_service_client = BlobServiceClient.from_connection_string("<AZURE_STORAGE_CONNECTION_STRING>")
    container_client = blob_service_client.get_container_client("your-container")

    log_rows = []
    timestamp_now = datetime.utcnow().isoformat()

    for item in payload:
        path = item.get("full_path")
        auth_id = item.get("auth_request_id")
        annotation_id = item.get("annotation_id")

        try:
            with sftp.open(path, 'rb') as f:
                blob_name = os.path.basename(path)
                container_client.upload_blob(name=blob_name, data=f, overwrite=True)
                log_rows.append([blob_name, path, auth_id, annotation_id, timestamp_now])
        except Exception as e:
            print(f"Error copying {path}: {e}")

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['file_name', 'full_path', 'auth_request_id', 'annotation_id', 'uploaded_at'])
    writer.writerows(log_rows)

    audit_blob_name = f"audit-logs/uploaded_{timestamp_now.replace(':', '_')}.csv"
    container_client.upload_blob(audit_blob_name, output.getvalue(), overwrite=True)

    sftp.close()
    transport.close()
